package com.example.assg4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Assg4Application {

	public static void main(String[] args) {

		SpringApplication.run(Assg4Application.class, args);
		System.out.println("Done !");
	}

}
