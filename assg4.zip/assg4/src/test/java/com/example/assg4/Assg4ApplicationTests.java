package com.example.assg4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Assg4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
